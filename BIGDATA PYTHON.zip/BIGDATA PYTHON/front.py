import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import csv
import json
import bcrypt  # Biblioteca para hashing de senhas
import os
import smtplib
from email.mime.text import MIMEText
from collections import defaultdict
from back import carregar_dados, gerar_analise_consumo, gerar_grafico, exportar_json, exportar_csv
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import pandas as pd

# Simulação de dados
usuarios = {
    "user1": bcrypt.hashpw("senha123".encode(), bcrypt.gensalt()),   
}

# Função para carregar o histórico de compras a partir do arquivo CSV
def carregar_historico_compras():
    historico_compras = {}
    pasta_arquivos = "arquivos_csv"  # Diretório onde os arquivos CSV estão
    
    arquivos = ["compras_agosto.csv", "compras_setembro.csv", "compras_outubro.csv"]
    
    for arquivo in arquivos:
        caminho_arquivo = os.path.join(pasta_arquivos, arquivo)  # Concatena o diretório com o nome do arquivo
        
        # Verifique se o arquivo existe antes de tentar abri-lo
        if not os.path.exists(caminho_arquivo):
            print(f"Erro: O arquivo {arquivo} não foi encontrado.")
            continue
        
        with open(caminho_arquivo, mode="r", newline="") as file:
            reader = csv.reader(file)
            next(reader)  # Pular o cabeçalho
            for row in reader:
                pedido, prato, data, preco, lucro = row
                if pedido not in historico_compras:
                    historico_compras[pedido] = []
                historico_compras[pedido].append((prato, data, preco, lucro))
    
    return historico_compras

# Inicialize o histórico de compras
historico_compras = carregar_historico_compras()

def verificar_senha(username, password):
    if username in usuarios and bcrypt.checkpw(password.encode(), usuarios[username]):
        return True
    return False

def login():
    username = entry_user.get()
    password = entry_pass.get()
    lembrar = var_lembrar.get()

    if verificar_senha(username, password):
        if lembrar:
            with open("lembrar_usuario.txt", "w") as f:
                f.write(username)
        else:
            try:
                os.remove("lembrar_usuario.txt")
            except FileNotFoundError:
                pass
                
        messagebox.showinfo("Login", "Login bem-sucedido!")
        root.after(100, abrir_tela_relatorio)  # Abre a tela de relatório após um pequeno atraso
    else:
        messagebox.showerror("Erro", "Usuário ou senha inválidos.")

def abrir_tela_relatorio():
    root.destroy()  # Fecha a janela de login
    tela_relatorio()  # Abre a tela de relatório

def exibir_historico_compras(pedido):
    historico = historico_compras.get(pedido, [])
    historico_texto = "\n".join([f"{item[0]} - {item[1]} - {item[2]} - {item[3]}" for item in historico])
    messagebox.showinfo("Histórico de Compras", f"Histórico para o pedido {pedido}:\n\n{historico_texto}")

def janela_login():
    global entry_user, entry_pass, root, var_lembrar, var_mostrar_senha
    root = tk.Tk()
    root.title("Login")
    root.geometry("950x900")
    root.configure(bg="#87CEEB")

    frame = tk.Frame(root, bg="#ffffff")
    frame.pack(expand=True, padx=20, pady=20)

    tk.Label(frame, text="Usuário", bg="#ffffff").grid(row=0, column=0, padx=10, pady=10)

    entry_user = tk.Entry(frame)
    entry_user.grid(row=0, column=1, padx=10, pady=10)
    entry_user.insert(0, carregar_usuario_salvo())

    tk.Label(frame, text="Senha", bg="#ffffff").grid(row=1, column=0, padx=10, pady=10)
    entry_pass = tk.Entry(frame, show="*")
    entry_pass.grid(row=1, column=1, padx=10, pady=10)

    var_mostrar_senha = tk.IntVar()
    tk.Checkbutton(frame, text="Mostrar senha", variable=var_mostrar_senha, 
                   command=alternar_visibilidade, bg="#ffffff").grid(row=2, columnspan=2)

    var_lembrar = tk.IntVar()
    tk.Checkbutton(frame, text="Lembre-me", variable=var_lembrar, bg="#ffffff").grid(row=3, columnspan=2, pady=20)

    tk.Button(frame, text="Login", command=login).grid(row=4, columnspan=2, pady=20)
    tk.Button(frame, text="Esqueci minha senha", command=recuperar_senha).grid(row=5, columnspan=2, pady=10)

    root.mainloop()
    
def carregar_usuario_salvo():
    try:
        with open("lembrar_usuario.txt", "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return ""

def alternar_visibilidade():
    if var_mostrar_senha.get():
        entry_pass.config(show="")
    else:
        entry_pass.config(show="*")

def recuperar_senha():
    email = tk.simpledialog.askstring("Recuperação de Senha", "Digite seu email:")

    if email:
        try:
            smtp_server = "smtp.gmail.com"
            smtp_port = 587
            email_remetente = "seuemail@gmail.com"
            senha_remetente = "suasenha"

            mensagem = MIMEText("Instruções para recuperação de senha...")
            mensagem["Subject"] = "Recuperação de Senha"
            mensagem["From"] = email_remetente
            mensagem["To"] = email

            with smtplib.SMTP(smtp_server, smtp_port) as servidor:
                servidor.starttls()
                servidor.login(email_remetente, senha_remetente)
                servidor.sendmail(email_remetente, email, mensagem.as_string())

            messagebox.showinfo("Recuperação de Senha", f"Um e-mail de recuperação foi enviado para {email}.")
        
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível enviar o e-mail: {e}")

# Função para exibir os botões de exportação na tela de análise
def mostrar_grafico(janela_analise, contador_pratos):
    # Gerar o gráfico de barras usando a função 'gerar_grafico'
    fig = gerar_grafico(contador_pratos)

    # Adicionar o gráfico à interface Tkinter
    canvas = FigureCanvasTkAgg(fig, master=janela_analise)
    canvas.draw()
    canvas.get_tk_widget().pack()  # Exibe o gráfico na janela do Tkinter

def tela_analise(periodo):
    janela_analise = tk.Tk()
    janela_analise.title(f"Análise de Consumo - {periodo.capitalize()}")
    janela_analise.geometry("800x600")  # Ajuste para uma largura maior para acomodar o gráfico ao lado

    # Mapeia os períodos para os nomes corretos dos arquivos
    arquivos_map = {
        "geral": "compras_geral.csv",  # Pode ser uma combinação de arquivos
        "agosto": "compras_agosto.csv",
        "setembro": "compras_setembro.csv",
        "outubro": "compras_outubro.csv",
    }

    pasta_arquivos = "arquivos_csv"  # Certifique-se de que esta pasta existe no seu projeto

    # Verifica se o período fornecido existe no mapeamento
    if periodo in arquivos_map:
        arquivo_csv = arquivos_map[periodo]
        caminho_arquivo = os.path.join(pasta_arquivos, arquivo_csv)
        
        # Verifica se o arquivo realmente existe
        if not os.path.exists(caminho_arquivo):
            messagebox.showerror("Erro", f"O arquivo {arquivo_csv} não foi encontrado.")
            return
        
        # Carregar dados do arquivo
        data = carregar_dados(caminho_arquivo)
        
        if data is not None:
            # Gerar a análise de consumo
            contador_pratos, total_preco, total_lucro = gerar_analise_consumo(data)
            
            # Exibir a análise na tela
            resultado_texto = f"Período: {periodo.capitalize()}\nTotal Recebido: R${total_preco:.2f}\nTotal lucro: R${total_lucro:.2f}\n\nPratos mais consumidos:\n"
            
            # Limitar para os 10 primeiros pratos mais consumidos
            for i, (prato, quantidade) in enumerate(contador_pratos.items(), start=1):
                if i > 10:  # Limitar a 10 pratos
                    break
                resultado_texto += f"{i}. {prato}: {quantidade} vezes\n"
            
            # Frame principal para organizar o layout horizontalmente
            main_frame = tk.Frame(janela_analise)
            main_frame.pack(pady=20, padx=20, expand=True, fill="both")

            # Frame para o texto e a barra de rolagem
            texto_frame = tk.Frame(main_frame)
            texto_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))  # Espaço à direita para o gráfico

            # Canvas e Scrollbar para o texto
            canvas = tk.Canvas(texto_frame)
            scrollbar = ttk.Scrollbar(texto_frame, orient="vertical", command=canvas.yview)
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame para o conteúdo do texto dentro do Canvas
            content_frame = tk.Frame(canvas)
            texto_analise = tk.Text(content_frame, wrap='word', height=15)
            texto_analise.insert('end', resultado_texto)
            texto_analise.pack(pady=10, expand=True, fill='both')

            # Posicionar o conteúdo no Canvas e configurar o scrollbar
            canvas.create_window((0, 0), window=content_frame, anchor="nw")
            scrollbar.pack(side="right", fill="y")
            canvas.pack(side="left", fill="both", expand=True)
            content_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

            # Frame para o gráfico
            grafico_frame = tk.Frame(main_frame)
            grafico_frame.pack(side="right", fill="both", expand=True)

            # Mostrar o gráfico ao lado
            mostrar_grafico(grafico_frame, contador_pratos)

            # Botões para exportar os dados
            btn_exportar_csv = tk.Button(janela_analise, text="Exportar para CSV", 
                                          command=lambda: exportar_csv(contador_pratos, total_preco, total_lucro, periodo))
            btn_exportar_csv.pack(pady=10)
            
            btn_exportar_json = tk.Button(janela_analise, text="Exportar para JSON", 
                                           command=lambda: exportar_json(contador_pratos, total_preco, total_lucro, periodo))
            btn_exportar_json.pack(pady=1)
        else:
            messagebox.showerror("Erro", "Falha ao carregar os dados.")
    else:
        messagebox.showerror("Erro", f"Período '{periodo}' não encontrado.")
    
    # Exibe a janela
    janela_analise.mainloop()

def tela_relatorio():
    janela_relatorio = tk.Tk()
    janela_relatorio.title("Relatório de Análise de Consumo")
    janela_relatorio.geometry("400x200")
    
    frame = tk.Frame(janela_relatorio)
    frame.pack(pady=10)

    # Botões para selecionar o período
    btn_geral = tk.Button(frame, text="Geral", command=lambda: tela_analise("geral"))
    btn_geral.grid(row=0, column=0, padx=10, pady=5)

    btn_agosto = tk.Button(frame, text="Agosto", command=lambda: tela_analise("agosto"))
    btn_agosto.grid(row=1, column=0, padx=10, pady=5)

    btn_setembro = tk.Button(frame, text="Setembro", command=lambda: tela_analise("setembro"))
    btn_setembro.grid(row=2, column=0, padx=10, pady=5)

    btn_outubro = tk.Button(frame, text="Outubro", command=lambda: tela_analise("outubro"))
    btn_outubro.grid(row=3, column=0, padx=10, pady=5)

    # Botão para voltar à tela de login
    btn_voltar = tk.Button(frame, text="Voltar", command=lambda: voltar_ao_login(janela_relatorio))
    btn_voltar.grid(row=4, column=0, padx=10, pady=5)

    janela_relatorio.mainloop()

def voltar_ao_login(janela_relatorio):
    janela_relatorio.destroy()  # Fecha a janela atual (relatório)
    janela_login()  # Chama a função de login novamente

janela_login()
