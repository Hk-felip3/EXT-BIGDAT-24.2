import os
import json
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def carregar_dados(arquivo_csv):
    try:
        data = pd.read_csv(arquivo_csv)
        if 'prato' not in data.columns or 'preco' not in data.columns or 'lucro' not in data.columns:
            print(f"Erro: O arquivo {arquivo_csv} não contém as colunas necessárias.")
            return None
        return data
    except FileNotFoundError:
        print(f"Erro: O arquivo {arquivo_csv} não foi encontrado.")
        return None
    except pd.errors.EmptyDataError:
        print(f"Erro: O arquivo {arquivo_csv} está vazio.")
        return None
    except Exception as e:
        print(f"Erro inesperado ao carregar o arquivo {arquivo_csv}: {e}")
        return None

def gerar_analise_consumo(data):
    if data is None:
        return None, None, None

    # Processar os dados (contagem dos pratos, totais de preço e lucro)
    contador_pratos = data['prato'].value_counts()  # Contagem dos pratos
    total_preco = data['preco'].sum()  # Total de preço
    total_lucro = data['lucro'].sum()  # Total de lucro
    return contador_pratos, total_preco, total_lucro

import matplotlib.pyplot as plt

def gerar_grafico(contador_pratos):
    # Cria o gráfico da frequência de pratos mais consumidos
    fig, ax = plt.subplots(figsize=(8, 6))
    top_pratos = contador_pratos.head(5)  # Limitar aos 5 pratos mais consumidos
    top_pratos.plot(kind='bar', color='skyblue', ax=ax)  # Passando ax para o plot do pandas
    ax.set_title('Top 5 Pratos Mais Consumidos')
    ax.set_xlabel('Prato')
    ax.set_ylabel('Quantidade')
    plt.tight_layout()

    return fig  # Retorna a figura criada

def exportar_csv(contador_pratos, total_preco, total_lucro, periodo):
    # Exporta os dados de análise para um arquivo CSV
    data_export = {
        "Prato": contador_pratos.index,
        "Quantidade": contador_pratos.values,
        "Total Preço": [total_preco] * len(contador_pratos),
        "Total Lucro": [total_lucro] * len(contador_pratos)
    }
    df_export = pd.DataFrame(data_export)
    df_export.to_csv(f"analise_consumo_{periodo}.csv", index=False)
    print(f"Dados exportados para CSV com sucesso para o período {periodo}.")

def exportar_json(contador_pratos, total_preco, total_lucro, periodo):
    # Exporta os dados de análise para um arquivo JSON
    data_export = {
        "periodo": periodo,
        "total_preco": total_preco,
        "total_lucro": total_lucro,
        "pratos": [{"prato": prato, "quantidade": quantidade} for prato, quantidade in contador_pratos.items()]
    }
    with open(f"analise_consumo_{periodo}.json", 'w') as json_file:
        json.dump(data_export, json_file, indent=4)
    print(f"Dados exportados para JSON com sucesso para o período {periodo}.")